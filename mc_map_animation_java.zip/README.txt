MC MAP ANIMATOR — Java Edition
============================================
Generated : 2026-04-20T01:56:05.060Z
Frames    : 200 @ 40 fps
Chunks    : 13 .nbt files
Wall dir  : south
Boat      : oak

FILE LAYOUT
-----------
structures/anim_X_0_0.nbt  → one file per 16-frame chunk
map_data/map_N.dat          → one file per frame (gzipped NBT)

INSTALLATION
------------
1. Copy map_data/map_*.dat  →  [world]/data/
2. Copy structures/*.nbt    →  [world]/generated/minecraft/structures/anim/
   (create the anim/ folder if needed)

3. Load each chunk in-game with /place structure (or a Structure Block).
   The structure block origin for chunk 0 is your reference point.
   Each subsequent chunk is offset +16 in X.

LOAD COMMANDS (run these from your reference origin block)
----------------------------------------------------------
/place structure minecraft:anim/anim_0_0_0 ~0 ~ ~
/place structure minecraft:anim/anim_16_0_0 ~16 ~ ~
/place structure minecraft:anim/anim_32_0_0 ~32 ~ ~
/place structure minecraft:anim/anim_48_0_0 ~48 ~ ~
/place structure minecraft:anim/anim_64_0_0 ~64 ~ ~
/place structure minecraft:anim/anim_80_0_0 ~80 ~ ~
/place structure minecraft:anim/anim_96_0_0 ~96 ~ ~
/place structure minecraft:anim/anim_112_0_0 ~112 ~ ~
/place structure minecraft:anim/anim_128_0_0 ~128 ~ ~
/place structure minecraft:anim/anim_144_0_0 ~144 ~ ~
/place structure minecraft:anim/anim_160_0_0 ~160 ~ ~
/place structure minecraft:anim/anim_176_0_0 ~176 ~ ~
/place structure minecraft:anim/anim_192_0_0 ~192 ~ ~

STRUCTURE LAYOUT (per chunk)
-----------------------------
  (x, y=0, z=0)  stone_bricks  — wall behind item frames
  (x, y=0, z=1)  packed_ice    — boat track
  entities        glow_item_frame at each x, holding filled_map{map:N}
  entity          oak_boat at (0.5, 0.0, 1.5) — first chunk only

MAP ID TABLE (first 30)
-----------------------
  frame 0  →  map_data/map_0.dat  (map ID: 0)
  frame 1  →  map_data/map_1.dat  (map ID: 1)
  frame 2  →  map_data/map_2.dat  (map ID: 2)
  frame 3  →  map_data/map_3.dat  (map ID: 3)
  frame 4  →  map_data/map_4.dat  (map ID: 4)
  frame 5  →  map_data/map_5.dat  (map ID: 5)
  frame 6  →  map_data/map_6.dat  (map ID: 6)
  frame 7  →  map_data/map_7.dat  (map ID: 7)
  frame 8  →  map_data/map_8.dat  (map ID: 8)
  frame 9  →  map_data/map_9.dat  (map ID: 9)
  frame 10  →  map_data/map_10.dat  (map ID: 10)
  frame 11  →  map_data/map_11.dat  (map ID: 11)
  frame 12  →  map_data/map_12.dat  (map ID: 12)
  frame 13  →  map_data/map_13.dat  (map ID: 13)
  frame 14  →  map_data/map_14.dat  (map ID: 14)
  frame 15  →  map_data/map_15.dat  (map ID: 15)
  frame 16  →  map_data/map_16.dat  (map ID: 16)
  frame 17  →  map_data/map_17.dat  (map ID: 17)
  frame 18  →  map_data/map_18.dat  (map ID: 18)
  frame 19  →  map_data/map_19.dat  (map ID: 19)
  frame 20  →  map_data/map_20.dat  (map ID: 20)
  frame 21  →  map_data/map_21.dat  (map ID: 21)
  frame 22  →  map_data/map_22.dat  (map ID: 22)
  frame 23  →  map_data/map_23.dat  (map ID: 23)
  frame 24  →  map_data/map_24.dat  (map ID: 24)
  frame 25  →  map_data/map_25.dat  (map ID: 25)
  frame 26  →  map_data/map_26.dat  (map ID: 26)
  frame 27  →  map_data/map_27.dat  (map ID: 27)
  frame 28  →  map_data/map_28.dat  (map ID: 28)
  frame 29  →  map_data/map_29.dat  (map ID: 29)
  ... (170 more)

PLAYBACK
--------
Push the boat along the packed ice track.
At 40 blocks/sec the animation plays at 40fps.
Use a piston, player push, or impulse to launch.
Place a barrier or wall at the end to stop the boat.
